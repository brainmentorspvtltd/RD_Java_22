package com.brainmentors.salaryslip.models;

public class Employee {
	private int id; // Instance Variable (When object is created then it comes in the memory)
	private String name;
	private double salary;
	private String companyName;
	
	
	
	
//	private class A{
//		
//	}
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	// Constructor
	/*
	 * What is Constructor
	 * When Object is created then constructor is called.
	 * Constructor is used to initalize the instance variables
	 * By default every class has default constructor
	 * Constructor name is same as class name
	 * Constructor not return any thing.
	 * Constructor Overloading
	 * 
	 */
	public Employee(){
		System.out.println("I am the Default constructor");
		companyName ="Brain Mentors";
	}
	public Employee(int id, String name, double salary){
		this();
		this.id = id;
		this.name = name;
		this.salary =salary;
	}
	
	public void print() {
		System.out.println("Id "+id+" name "+name+" Salary "+salary+" Company Name "+companyName);
	}
	
	void Employee() {
		System.out.println("I am a  Method");
	}
}
