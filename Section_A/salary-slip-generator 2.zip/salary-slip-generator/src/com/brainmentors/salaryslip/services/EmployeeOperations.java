package com.brainmentors.salaryslip.services;
// Allowances Compute Logic
public class EmployeeOperations {
	private double salary;
	public EmployeeOperations(double salary) {
		this.salary = salary;
	}
	
	public double hra() {
		return salary * 0.50;
	}
	
public double da() {
	return salary * 0.20;
	}

public double ta() {
	return salary * 0.30;
}

public double ma() {
	return salary * 0.25;
}

public double pf() {
	return salary * 0.05;
}

public double gs() {
	return salary + hra() + da() + ta() + ma();
}

public double tax() {
	return gs() * 0.10;
}

public double ns() {
	return gs() - tax() - pf();
}

}
