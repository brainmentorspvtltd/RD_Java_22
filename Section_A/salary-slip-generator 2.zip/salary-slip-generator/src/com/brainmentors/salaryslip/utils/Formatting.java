package com.brainmentors.salaryslip.utils;

import java.text.NumberFormat;
import java.util.Locale;

public class Formatting {
	
	Locale locale = new Locale("hi","IN");
	
	public String formatCurrency(double value){
		NumberFormat nf = NumberFormat.getCurrencyInstance(locale);
		return nf.format(value);
	}

}
