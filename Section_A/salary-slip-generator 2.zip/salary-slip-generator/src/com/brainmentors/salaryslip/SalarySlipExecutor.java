package com.brainmentors.salaryslip;

import com.brainmentors.salaryslip.models.Employee;
import com.brainmentors.salaryslip.services.EmployeeOperations;
import com.brainmentors.salaryslip.views.Printing;
import com.brainmentors.salaryslip.views.UserInput;

public class SalarySlipExecutor {

	public static void main(String[] args) {
		UserInput userInput = new UserInput();
		Employee emp = userInput.takeInput();
		EmployeeOperations opr = new EmployeeOperations(emp.getSalary());
		Printing printing = new Printing();
		printing.printSalarySlip(emp, opr);
		
		// TODO Auto-generated method stub
//		Employee ram = new Employee(1001, "ram kumar", 9999);
//	//	Employee ram2 = new Employee();
//		ram.print();

	}

}
