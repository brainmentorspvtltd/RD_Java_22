package com.brainmentors.salaryslip.views;

import com.brainmentors.salaryslip.models.Employee;
import com.brainmentors.salaryslip.services.EmployeeOperations;
import com.brainmentors.salaryslip.utils.Formatting;

public class Printing {
	Formatting formatting = new Formatting();
	public void printSalarySlip(Employee emp, EmployeeOperations opr) {
		System.out.println("Salary Slip****************");
		emp.print();
		System.out.println("Hra "+formatting.formatCurrency(opr.hra()));
		System.out.println("DA "+formatting.formatCurrency(opr.da()));
		System.out.println("TA "+opr.ta());
		System.out.println("MA "+opr.ma());
		System.out.println("PF "+opr.pf());
		System.out.println("Tax "+opr.tax());
		System.out.println("GS "+opr.gs());
		System.out.println("NS "+opr.ns());
		
	}

}
