package com.brainmentors.salaryslip.models;

public class Employee {
	private int id;
	private String name;
	private double salary;
}
