package com.brainmentors.salaryslip.views;

public class UserInput {

}
