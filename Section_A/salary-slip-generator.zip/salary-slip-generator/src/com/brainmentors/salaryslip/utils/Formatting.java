package com.brainmentors.salaryslip.utils;

public class Formatting {

}
