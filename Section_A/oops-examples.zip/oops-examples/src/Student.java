// Class Name - Pascal Case
// RegularStudent
// DistanceLearningStudent
// Encapsulation - Binding Data and Functions together in a single unit and that unit is called class.
// Good Encapsulation - Private Data + public functions
public class Student {
	// Data Hiding
	private int rollno; // Instance Variables , When u create the object , it is called instance creation.
	// During instance creation, instance variables memory will be allocate.
	private String name;
	private String course;
	private String email;
	
	boolean validateRollNo(int rollno) {
		if(rollno<=0) {
			System.out.println("Invalid Data");
			return false;
		}
		return true;
	}
	
	// Local Variables
	public void takeInput(int rollno, String name, String course, String email) {
		// Instance Var = Local var
		// this - keyword (It contains the  current calling object reference)
		if(!validateRollNo(rollno)) {
			return ;
		}
		this.rollno = rollno;
		this.name = name;
		this.course = course;
		this.email = email;
		// Shadow Problem
	}
	
	public void print() {
		System.out.println("Id "+rollno+" Name "+name +" Course "+course +" Email "+email);
	}
	// Student Features
	// variables + methods (camelCase)
	// eg. checkBalance
	}
