
public class TestStudent {

	public static void main(String[] args) {
		Student student = new Student();
		student.takeInput(1001, "Ram", "Java", "ram@brainmentors.com");
		student.print();
		//student.rollno=-1111;
//		System.out.println("Rollno "+student.rollno);
//		System.out.println("Name "+student.name);
//		System.out.println("Course "+student.course);
//		System.out.println("Email "+student.email);
//		
//		//new keyword (Allocate Memory Dynamically)
//		int x = 10;

	}


}
