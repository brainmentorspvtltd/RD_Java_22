//S - SRP
public class TestStudent {

	public static void main(String[] args) {
		Student ram = new Student();
		ram.takeInput(1010, "ram", "java");
		ram.print();
//		ram.rollno = -1010;
//		ram.name = "";
//		ram.course = "java";
//		System.out.println(ram.rollno);
//		System.out.println(ram.name);
//		System.out.println(ram.course);
		int x =10;

	}

}
