// Class - Data Members + Functions
public class Student {
	// Data Hiding
	// Instance Variable
	 private int rollno; // Members
	 private String name;
	 private String course;
	 
	 public boolean validate(int rollno, String name) {
		 if(rollno<=0 || name.length()==0) {
				System.out.println("Invalid Data");
				return false;
			}
		 return true;
	 }
	 
	 // Local var
	 public void takeInput(int rollno, String name, String course) {
		if(!validate(rollno, name)) {
			return ;
		}
		this.rollno = rollno;
		this.name = name;
		this.course = course;
		// this
		// Instance Var = Local Var
	 }
	 
	 public void print() {
		 System.out.println("Rollno "+rollno);
		 System.out.println("Name "+name);
		 System.out.println("Course "+course);
	 }
	
	 
}
